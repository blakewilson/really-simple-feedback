=== Plugin Name ===
Contributors: pushlabs
Tags: really simple feedback, feedback, es6, javascript
Requires at least: 4.5
Tested up to: 5.2.2
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A really simple way to get feedback from your users.

== Description ==

Really Simple Feedback is a really simple way for your users to submit feedback about your WordPress site and pages in a clean and easy way.

== Installation ==

1. Upload `really-simple-feedback.zip` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. That's it!

== Frequently Asked Questions ==

= What browsers are compatible? =

Really Simple Feedback supports all modern browsers and IE 11.

== Changelog ==

= 1.0.0 =
* Initial Release